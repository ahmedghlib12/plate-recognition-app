"""تحليل رقم اللوحة العراقية: رمز المحافظة - حرف - رقم."""
import re

_AR_DIGITS = str.maketrans("٠١٢٣٤٥٦٧٨٩", "0123456789")
PATTERN = re.compile(r"(\d{1,2})\s*-?\s*([A-Za-z\u0600-\u06FF])\s*-?\s*(\d{3,6})")


def normalize_digits(text):
    return text.translate(_AR_DIGITS)


def parse_plate(text):
    """يرجع dict بأجزاء اللوحة أو None إن لم ينطبق النمط."""
    text = normalize_digits(text or "")
    m = PATTERN.search(text)
    if not m:
        return None
    code, letter, number = m.groups()
    return {
        "code": code,
        "letter": letter.upper(),
        "number": number,
        "formatted": f"{code}-{letter.upper()} {number}",
    }
